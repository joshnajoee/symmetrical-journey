import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface FormFieldProps {
  label: string;
  type: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  placeholder?: string;
  required?: boolean;
}

export const FormField: React.FC<FormFieldProps> = ({
  label,
  type,
  name,
  value,
  onChange,
  error,
  placeholder,
  required = false,
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [focused, setFocused] = useState(false);

  const isPassword = type === 'password';
  const inputType = isPassword && showPassword ? 'text' : type;
  const hasValue = value && value.length > 0;
  const isActive = focused || hasValue;

  return (
    <div className="relative">
      <div className="relative">
        <input
          type={inputType}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={isActive ? placeholder : ''}
          required={required}
          className={`
            w-full px-4 py-3 bg-white border rounded-xl transition-all duration-300
            focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500
            ${error ? 'border-red-300 focus:border-red-500 focus:ring-red-500/20' : 'border-gray-200'}
            ${isActive ? 'pt-6 pb-2' : 'py-3'}
            text-gray-900 placeholder-gray-400
          `}
        />
        
        <label
          htmlFor={name}
          className={`
            absolute left-4 transition-all duration-300 pointer-events-none
            ${isActive 
              ? 'top-2 text-xs font-medium text-gray-500' 
              : 'top-1/2 -translate-y-1/2 text-base text-gray-500'
            }
            ${focused && !error ? 'text-blue-600' : ''}
            ${error ? 'text-red-600' : ''}
          `}
        >
          {label}
        </label>

        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            {showPassword ? (
              <EyeOff className="w-5 h-5" />
            ) : (
              <Eye className="w-5 h-5" />
            )}
          </button>
        )}
      </div>
      
      {error && (
        <p className="mt-2 text-sm text-red-600 animate-fadeIn">
          {error}
        </p>
      )}
    </div>
  );
};